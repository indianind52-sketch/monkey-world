# Monkey World

Interactive 3D monkey (React + Vite + React Three Fiber + Drei). The monkey is
generated in code (`src/Monkey.jsx`) – no GLB, texture or any other asset file is needed.

    npm install
    npm run dev       # local dev server
    npm run build     # production build into dist/

Deploy free on Vercel: push to GitHub, import the repo, keep the detected Vite defaults, click Deploy.
