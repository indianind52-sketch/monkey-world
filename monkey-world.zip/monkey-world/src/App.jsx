import { useEffect, useRef, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { PerformanceMonitor } from '@react-three/drei'
import Monkey from './Monkey.jsx'
import Particles from './Particles.jsx'

const isCoarse =
  typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches

export default function App() {
  // Normalised pointer / finger position: x,y in -1..1 (y up)
  const pointer = useRef({ x: 0, y: 0 })
  const [dpr, setDpr] = useState(isCoarse ? 1.25 : 1.75)

  useEffect(() => {
    const set = (e) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1
      pointer.current.y = -((e.clientY / window.innerHeight) * 2 - 1)
    }
    // Mouse: keep last position. Touch: look forward again when the finger lifts.
    const release = (e) => {
      if (e.pointerType !== 'mouse') pointer.current = { x: 0, y: 0 }
    }
    const leave = () => (pointer.current = { x: 0, y: 0 })

    window.addEventListener('pointermove', set, { passive: true })
    window.addEventListener('pointerdown', set, { passive: true })
    window.addEventListener('pointerup', release)
    window.addEventListener('pointercancel', release)
    document.documentElement.addEventListener('mouseleave', leave)
    return () => {
      window.removeEventListener('pointermove', set)
      window.removeEventListener('pointerdown', set)
      window.removeEventListener('pointerup', release)
      window.removeEventListener('pointercancel', release)
      document.documentElement.removeEventListener('mouseleave', leave)
    }
  }, [])

  return (
    <main className="hero">
      <Canvas
        dpr={dpr}
        camera={{ position: [0, 0.2, 8.5], fov: 35 }}
        gl={{ antialias: !isCoarse, powerPreference: 'high-performance', alpha: true }}
      >
        <PerformanceMonitor onDecline={() => setDpr(1)} />
        <hemisphereLight args={['#c9b8ff', '#2a1a10', 0.7]} />
        <directionalLight position={[3, 5, 6]} intensity={2.2} color="#fff1d6" />
        <pointLight position={[-5, 2, -2]} intensity={40} color="#3ee0c8" />
        <pointLight position={[5, -1, -3]} intensity={30} color="#8b5cff" />
        <Monkey pointer={pointer} />
        <Particles count={isCoarse ? 90 : 220} />
      </Canvas>

      <div className="overlay">
        <h1 className="title">WELCOME TO MY WORLD</h1>
        <div className="bottom">
          <p className="subtitle">Say hi. He's been watching your cursor since you arrived.</p>
          <a className="cta" href="#explore">Come on in</a>
        </div>
      </div>
    </main>
  )
}
