import { useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { ContactShadows } from '@react-three/drei'
import { MathUtils } from 'three'

const FUR = '#7a4a2b'
const FUR_DARK = '#5a3420'
const SKIN = '#ecbd93'
const { damp } = MathUtils

function Eye({ x, eyeRef, pupilRef }) {
  return (
    <group ref={eyeRef} position={[x, 0.12, 0.9]}>
      <mesh>
        <sphereGeometry args={[0.17, 20, 20]} />
        <meshStandardMaterial color="#ffffff" roughness={0.3} />
      </mesh>
      <mesh ref={pupilRef} position={[0, 0, 0.13]}>
        <sphereGeometry args={[0.085, 14, 14]} />
        <meshStandardMaterial color="#111111" roughness={0.1} />
      </mesh>
    </group>
  )
}

/**
 * Procedural monkey (no external asset needed). `pointer` is a ref holding
 * { x, y } in the range -1..1 (screen space, y up).
 */
export default function Monkey({ pointer }) {
  const { viewport } = useThree()
  const s = Math.min(0.8, viewport.width / 4.4)
  const baseY = 0.55

  const root = useRef()
  const body = useRef()
  const head = useRef()
  const eyeL = useRef()
  const eyeR = useRef()
  const pupilL = useRef()
  const pupilR = useRef()
  const nextBlink = useRef(1.5)
  const blinkStart = useRef(-10)

  useFrame(({ clock }, dt) => {
    const t = clock.elapsedTime
    const p = pointer.current
    dt = Math.min(dt, 0.05)

    // Idle motion
    root.current.position.y = baseY + Math.sin(t * 1.6) * 0.05 * s
    body.current.rotation.z = Math.sin(t * 1.1) * 0.025

    // Head follows pointer (smoothed)
    head.current.rotation.y = damp(head.current.rotation.y, p.x * 0.85 + Math.sin(t * 0.7) * 0.03, 5, dt)
    head.current.rotation.x = damp(head.current.rotation.x, -p.y * 0.5 + Math.sin(t * 0.9) * 0.02, 5, dt)
    head.current.rotation.z = damp(head.current.rotation.z, -p.x * 0.08, 4, dt)
    body.current.rotation.y = damp(body.current.rotation.y, p.x * 0.2, 3, dt)

    // Pupils drift toward pointer
    for (const ref of [pupilL, pupilR]) {
      ref.current.position.x = damp(ref.current.position.x, p.x * 0.04, 8, dt)
      ref.current.position.y = damp(ref.current.position.y, p.y * 0.04, 8, dt)
    }

    // Blinking
    if (t > nextBlink.current) {
      blinkStart.current = t
      nextBlink.current = t + 2 + Math.random() * 3
    }
    const b = t - blinkStart.current
    const k = b < 0.16 ? Math.sin((b / 0.16) * Math.PI) : 0
    eyeL.current.scale.y = eyeR.current.scale.y = 1 - 0.92 * k
  })

  return (
    <>
      <group ref={root} scale={s} position={[0, baseY, 0]}>
        <group ref={body}>
          {/* Torso */}
          <mesh position={[0, -1.9, 0]} scale={[1.05, 1.15, 0.9]}>
            <sphereGeometry args={[1, 28, 28]} />
            <meshStandardMaterial color={FUR} roughness={0.85} />
          </mesh>
          <mesh position={[0, -1.9, 0.72]} scale={[0.66, 0.82, 0.5]}>
            <sphereGeometry args={[1, 24, 24]} />
            <meshStandardMaterial color={SKIN} roughness={0.8} />
          </mesh>
          {/* Arms */}
          <mesh position={[-1.2, -1.8, 0.1]} rotation={[0, 0, 0.3]}>
            <capsuleGeometry args={[0.24, 0.9, 6, 12]} />
            <meshStandardMaterial color={FUR_DARK} roughness={0.85} />
          </mesh>
          <mesh position={[1.2, -1.8, 0.1]} rotation={[0, 0, -0.3]}>
            <capsuleGeometry args={[0.24, 0.9, 6, 12]} />
            <meshStandardMaterial color={FUR_DARK} roughness={0.85} />
          </mesh>

          {/* Head */}
          <group ref={head} position={[0, -0.05, 0]}>
            <mesh>
              <sphereGeometry args={[1, 36, 36]} />
              <meshStandardMaterial color={FUR} roughness={0.85} />
            </mesh>
            {[-1, 1].map((side) => (
              <group key={side} position={[side * 1.0, 0.1, 0]}>
                <mesh scale={[1, 1, 0.6]}>
                  <sphereGeometry args={[0.34, 20, 20]} />
                  <meshStandardMaterial color={FUR} roughness={0.85} />
                </mesh>
                <mesh position={[0, 0, 0.1]} scale={[1, 1, 0.5]}>
                  <sphereGeometry args={[0.22, 16, 16]} />
                  <meshStandardMaterial color={SKIN} roughness={0.8} />
                </mesh>
              </group>
            ))}
            {/* Face patch */}
            <mesh position={[0, -0.1, 0.62]} scale={[0.78, 0.68, 0.5]}>
              <sphereGeometry args={[1, 28, 28]} />
              <meshStandardMaterial color={SKIN} roughness={0.75} />
            </mesh>
            <Eye x={-0.3} eyeRef={eyeL} pupilRef={pupilL} />
            <Eye x={0.3} eyeRef={eyeR} pupilRef={pupilR} />
            {/* Muzzle */}
            <mesh position={[0, -0.38, 0.95]} scale={[0.38, 0.28, 0.3]}>
              <sphereGeometry args={[1, 24, 24]} />
              <meshStandardMaterial color="#f3cfaa" roughness={0.7} />
            </mesh>
            <mesh position={[-0.07, -0.3, 1.22]}>
              <sphereGeometry args={[0.035, 10, 10]} />
              <meshStandardMaterial color="#2b1810" />
            </mesh>
            <mesh position={[0.07, -0.3, 1.22]}>
              <sphereGeometry args={[0.035, 10, 10]} />
              <meshStandardMaterial color="#2b1810" />
            </mesh>
            <mesh position={[0, -0.44, 1.2]} rotation={[0, 0, Math.PI]}>
              <torusGeometry args={[0.14, 0.02, 8, 24, Math.PI]} />
              <meshStandardMaterial color="#2b1810" />
            </mesh>
          </group>
        </group>
      </group>
      <ContactShadows
        position={[0, baseY - 3.05 * s, 0]}
        opacity={0.55}
        scale={8}
        blur={2.5}
        far={4}
        resolution={256}
        color="#000000"
      />
    </>
  )
}
